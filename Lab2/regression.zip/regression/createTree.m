function  [tree]  = createTree(data,label,RV,RN,feature )
    
    feature_name = {'Displacement','HorsePower','Weight','Acceleration'};
    tree = struct('op', [], 'kids', [], 'prediction', [], 'attribute', [], 'threshold', []);
    
    [Index,value] = Choose(data,label, RV,RN );
    

    if Index == 0
        tree.op = [];
        tree.attribute = [];
        tree.prediction = value;
        tree.threshold = [];
        tree.kids = cell(0);
        return
    else
        tree.op = feature_name{Index};
        tree.attribute = Index;
        tree.prediction = [];
        tree.threshold = value;
        feature = [feature, Index];
    end
    
    [lSet,llab,rSet,rlab] = Split(data,label, Index, value);

    tree.kids = {createTree( lSet,llab,RV,RN,feature ), createTree( rSet,rlab,RV,RN,feature)};
    
end